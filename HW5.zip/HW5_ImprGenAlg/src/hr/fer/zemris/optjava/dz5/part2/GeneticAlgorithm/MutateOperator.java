package hr.fer.zemris.optjava.dz5.part2.GeneticAlgorithm;

public class MutateOperator {

	public int[] mutate(int[] child) {
		return null;
	}
	
}
