package hr.fer.zemris.optjava.dz5.part2.GeneticAlgorithm;

public class SelectionOperator {

	public int[][] choose() {
		return null;
	}
	
}
