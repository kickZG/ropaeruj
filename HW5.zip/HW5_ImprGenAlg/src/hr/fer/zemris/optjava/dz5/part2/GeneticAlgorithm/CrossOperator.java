package hr.fer.zemris.optjava.dz5.part2.GeneticAlgorithm;

public class CrossOperator {

	public int[] cross() {
		return null;
	}
	
}
