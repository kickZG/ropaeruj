package hr.fer.zemris.optjava.dz5.part2.GeneticAlgorithm;

public class FitnessFunction {

	public int getValue(int[] permutation) {
		return 0;
	}
	
}
