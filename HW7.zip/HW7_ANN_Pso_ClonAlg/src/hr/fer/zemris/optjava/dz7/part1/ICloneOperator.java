package hr.fer.zemris.optjava.dz7.part1;

public interface ICloneOperator {

	public double[][] clone(double[][] p);
	
}
