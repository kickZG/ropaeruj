package hr.fer.zemris.optjava.dz7.part1;

public interface IMutateOperator {

	public double[][] hypermutate(double[][] p);
	
}
