package hr.fer.zemris.optjava.dz7.part1;

public interface ITransferFunction {

	public double getValue(double net);
	
}
