package hr.fer.zemris.optjava.dz3;

public interface IFunction {

	public double valueAt(double[] solution);
	
}
