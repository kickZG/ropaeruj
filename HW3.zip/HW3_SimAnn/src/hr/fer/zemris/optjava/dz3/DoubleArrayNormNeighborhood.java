package hr.fer.zemris.optjava.dz3;

import java.util.Random;

public class DoubleArrayNormNeighborhood implements INeighborhood<DoubleArraySolution> {

	private double[] deltas;
	Random rand;
	
	public DoubleArrayNormNeighborhood(double[] deltas) {
		this.deltas = deltas;
	}
	
	@Override
	public DoubleArraySolution randomNeighbor(DoubleArraySolution object) {
		// TODO Auto-generated method stub
		return null;
	}

}
