package hr.fer.zemris.optjava.dz3;

import java.util.Random;

public class DoubleArraySolution extends SingleObjectiveSolution {

	private double[] values;
	
	public DoubleArraySolution(int n) {
		
	}
	
	public DoubleArraySolution newLikeThis() {
		return null;
	}
	
	public DoubleArraySolution duplicate() {
		return null;
	}
	
	public void randomize(Random r, double[] firstArray, double[] secondArray) {
		
	}

	public double[] getValues() {
		return values;
	}

	public void setValues(double[] values) {
		this.values = values;
	}

}
