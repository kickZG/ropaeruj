package hr.fer.zemris.optjava.dz3;

public class PassThroughDecoder implements IDecoder<DoubleArraySolution> {

	public PassThroughDecoder() {
		
	}
	
	@Override
	public double[] decode(DoubleArraySolution das) {
		return null;
	}

	@Override
	public void decode(DoubleArraySolution das, double[] values) {
		// TODO Auto-generated method stub
		
	}

}
