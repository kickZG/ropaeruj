package hr.fer.zemris.optjava.dz4.part1;

public interface IDoubleMutation {

	public double[] mutate(double[] solution);
	
}
