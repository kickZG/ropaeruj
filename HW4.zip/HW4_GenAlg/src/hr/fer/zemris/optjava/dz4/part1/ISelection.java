package hr.fer.zemris.optjava.dz4.part1;

public interface ISelection {

	public int choose(double[] fitness);
	
}
