package hr.fer.zemris.optjava.dz4.part1;

public interface ICrossOperator {

	public double[] cross(double[] parent1, double[] parent2);
	
}
