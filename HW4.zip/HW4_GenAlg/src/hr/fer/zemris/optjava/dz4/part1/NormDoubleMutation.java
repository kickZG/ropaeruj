package hr.fer.zemris.optjava.dz4.part1;

public class NormDoubleMutation implements IDoubleMutation {

	@Override
	public double[] mutate(double[] solution) {
		// TODO Auto-generated method stub
		return null;
	}

}
